from tkinter import *

###################################################################################
# Classe de base pour les objets à dessiner
###################################################################################
class Objet():
    def __init__(self, canvas):
        self.canvas  = canvas

class Rectangle(Objet):
    def __init__(self, canvas, x0, y0, w, h, bg0, bg1):
        super().__init__(canvas)

        # On met l'objet dans la liste des objets du canvas
        self.canvas.objets.append(self)
        
        # Paramètres géométriques
        self.x0 = x0
        self.y0 = y0
        self.w = w
        self.h = h

        # Couleurs
        self.bg0 = bg0
        self.bg1 = bg1
        self.bg = self.bg0 # Couleur courante
        
        # Point cliqué
        self.dx = self.dy = None
        
        # On dessine l'objet
        self.draw()


    def est_dedans(self, x, y):
        """ Renvoie True si le point (x,y) est à l'intérieur de l'objet
        """
        return self.x0 < x < self.x0 + self.w and self.y0 < y < self.y0 + self.h
    

    def mousemove(self, event):
        """ Actions réalisées quand la souris est déplacée
        """
        x, y = event.x, event.y

        # Changement de couleur
        if self.est_dedans(x, y):
            self.bg = self.bg1
        else:
            self.bg = self.bg0

        # Drag
        if self.dx is not None: # drag en cours
            self.x0 = x - self.dx
            self.y0 = y - self.dy

        self.draw()


    def mousedown(self, event):
        """ Actions réalisées quand le bouton de la souris est appuyé
        """
        x, y = event.x, event.y

        # Début du drag : on mémorise la position relative du curseur de la souris
        if self.est_dedans(x, y):
            self.dx = event.x - self.x0
            self.dy = event.y - self.y0


    def mouseup(self, event):
        """ Actions réalisées quand le bouton de la souris est relâché
        """
        x, y = event.x, event.y
        # Fin du drag
        self.dx = self.dy = None


    def draw(self):
        if hasattr(self, 'id'): # l'objet a déja été dessiné
            self.canvas.delete(self.id)
        self.id = self.canvas.create_rectangle((self.x0, self.y0), 
                                               (self.x0 + self.w, self.y0 + self.h), 
                                               fill = self.bg)



###################################################################################
# Classe définissant le canvas où sont dessinés les objets
###################################################################################
class Dessin(Canvas):
    def __init__(self, fen, width, height, bg):
        super().__init__(fen, width = width, height=height, bg=bg)
        self.objets = []
        
        # Liaisons des événements à des méthodes
        self.bind('<Motion>', self.mousemove)
        self.bind('<Button-1>', self.mousedown)
        self.bind('<ButtonRelease-1>', self.mouseup)
        
    def draw(self):
        for o in self.objets:
            o.draw()

    def mousemove(self, event):
        for o in self.objets:
            o.mousemove(event)

    def mousedown(self, event):
        for o in self.objets:
            o.mousedown(event)
    
    def mouseup(self, event):
        for o in self.objets:
            o.mouseup(event)


###################################################################################
# Classe définissant l'objet représentant la fenêtre principale de l'application
###################################################################################
class Application(Tk):
    def __init__(self, w, h):
        super().__init__()
        self.title("Faites glisser les figures")   # Le titre de la fenêtre
        self.w = w
        self.h = h
        self.minsize(self.w, self.h)      # taille de fenêtre
        self.geometry(f"{self.w}x{self.h}")
        self.update()

        # Une méthode séparée pour construire le contenu de la fenêtre
        self.createWidgets()

    def get_size(self):
        return self.winfo_width(), self.winfo_height()

    # Méthode de création des widgets
    def createWidgets(self):
        self.grid()      # Choix du mode d'arrangement
       
        # Création des widgets
        self.dessin = Dessin(self, width = self.winfo_width(), 
                                   height = self.winfo_height()-30, 
                                   bg = "ivory")
        a = Rectangle(self.dessin, 10, 20, 100, 200, "white", "blue")
        b = Rectangle(self.dessin, 120, 50, 160, 180, "green", "red")
        self.dessin.grid()
        
        # Un bouton pour quitter l'application
        self.quitButton = Button(self, text = "Quitter", 
                                 command = self.destroy)
        self.quitButton.grid()


app = Application(600, 400)
app.mainloop()