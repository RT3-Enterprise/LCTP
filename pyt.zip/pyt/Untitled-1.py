from tkinter import messagebox

messagebox.showinfo("information", "Ceci est un message d'information")
messagebox.showwarning("ALERTE", "UNE ALERTE A éTAIT D'éCLANCHER")
messagebox.showerror("Message d'erreur", "Ceci est un message d'erreur")
reponse = messagebox.askokcancel("Question", "Voulez-vous continuer ?")
